<?php

?>


<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->




	<head>

<!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">
    
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Move To Success Physical Therapy</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Move To Success Physical Therapy Troy Michigan" /><!--///// MANUAL  /////-->
	<meta name="keywords" content="Move To Success Physical Therapy" /><!--///// MANUAL  /////-->
	<meta name="author" content="Move To Success Physical Therapy" /><!--///// MANUAL  /////-->
		
	<link rel="shortcut icon" href="images/favicon.ico">

	<!--///// GOOGLE FONTS  
	<link href="https://fonts.googleapis.com/css?family=Roboto:300,400" rel="stylesheet" rel="stylesheet">
/////-->
	<!-- Animate.css -->
<link rel="stylesheet" href="http://movetosuccesspt.com/wp-content/themes/moveTheme/css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="http://movetosuccesspt.com/wp-content/themes/moveTheme/css/icomoon.css">
	<!-- Simple Line Icons -->
	<link rel="stylesheet" href="http://movetosuccesspt.com/wp-content/themes/moveTheme/css/simple-line-icons.css">
	<!-- Owl Carousel -->
	<link rel="stylesheet" href="http://movetosuccesspt.com/wp-content/themes/moveTheme/css/owl.carousel.min.css">
	<link rel="stylesheet" href="http://movetosuccesspt.com/wp-content/themes/moveTheme/css/owl.theme.default.min.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="http://movetosuccesspt.com/wp-content/themes/moveTheme/css/bootstrap.css">
	<!-- Main Style  -->
	<link rel="stylesheet" href="{{ URL::asset('/css/style.css')}}">
	<!-- Modernizr JS -->
	<script src="http://movetosuccesspt.com/wp-content/themes/moveTheme/js/modernizr-2.6.2.min.js"></script>
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->
	</head>
	<body>
		
		

														

		</header>