

@extends ('layout')


@section('content')


<div id="fh5co-pricing" data-section="about">
	<div class="container">


		<div class="frontPageNote">
			<h2> MySpy</h2>
		</div>

		<div id="fh5co-testimonials" >		
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<h2> {{$all_txn_nums}}</h2>

						<p> paragra</p>
						
					</div>
				</div>
			</div>
		</div>
	</div>
</div>


@endsection('content')

