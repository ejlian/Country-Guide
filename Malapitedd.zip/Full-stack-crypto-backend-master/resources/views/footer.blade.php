<!--///// FOOTER  START  /////-->
	<footer id="footer" role="contentinfo">
		<div class="container">
			<div class="row">
				<div class="col-md-12 text-center">
					<ul class="social social-circle">
						<center>
						<li><a href="https://www.facebook.com/MoveToSuccessPT/"><i class="icon-facebook"></i></a></li>
						<li><a href="https://www.instagram.com/dr.mandykirkdpt/"><i class="icon-instagram"></i></a></li>
						<li><a href="https://www.linkedin.com/company/move-to-success-physical-therapy/"><i class="icon-linkedin"></i></a></li>
						
						</center>
					</ul>
				</div>
			</div>
				
			<div class="row row-bottom-padded-sm">
				<div class="col-md-12">
					<p class="copyright text-center">&copy; Move To Success Physical Therapy. All Rights Reserved.</p>
					<p class="copyright text-center"><a href="http://movetosuccesspt.com/privacy/" style="color:white;">Privacy Policy</a> | <a href="http://movetosuccesspt.com/contact/" style="color:white;">Contact Us</a></p>
				</div>
			</div>
		
		</div>
		</footer>
<!--///// FOOTER  END /////-->


	<!-- jQuery -->
	<script src="http://movetosuccesspt.com/wp-content/themes/moveTheme/js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="http://movetosuccesspt.com/wp-content/themes/moveTheme/js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="http://movetosuccesspt.com/wp-content/themes/moveTheme/js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="http://movetosuccesspt.com/wp-content/themes/moveTheme/js/jquery.waypoints.min.js"></script>
	<!-- Owl Carousel -->
	<script src="http://movetosuccesspt.com/wp-content/themes/moveTheme/js/owl.carousel.min.js"></script>
	<!-- Main JS (Do not remove) -->
	<script src="http://movetosuccesspt.com/wp-content/themes/moveTheme/js/main.js"></script>

	</body>
</html>