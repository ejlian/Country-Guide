<?php

use Faker\Generator as Faker;

$factory->define(App\UserBalance::class, function (Faker $faker) {
    return [
        //
    ];
});
