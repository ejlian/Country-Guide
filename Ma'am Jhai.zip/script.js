
var firebaseConfig = {
  apiKey: "AIzaSyDQ7el_1eVYkiUpTlAoQuIqpgI1hXRWnP4",
  authDomain: "country-guide-app.firebaseapp.com",
  projectId: "country-guide-app",
  storageBucket: "country-guide-app.appspot.com",
  messagingSenderId: "572767959037",
  appId: "1 :572767959037:web:e7bb7ba50177c1fd5d0b94"
};

firebase.initializeApp(firebaseConfig);

let searchBtn = document.getElementById("search-btn");
let countryInp = document.getElementById("country-inp");
let result = document.getElementById("result");
let compareBtn = document.getElementById("compare-btn");
let countryCompareInp = document.getElementById("country-compare-inp");
let compareResult = document.getElementById("compare-result");
let signupBtn = document.getElementById("signup-btn");
let loginBtn = document.getElementById("login-btn");
let logoutBtn = document.getElementById("logout-btn");

signupBtn.addEventListener("click", () => {
  let email = document.getElementById("email").value;
  let password = document.getElementById("password").value;
  firebase.auth().createUserWithEmailAndPassword(email, password)
    .then((userCredential) => {
      alert("User signed up successfully!");
    })
    .catch((error) => {
      alert(error.message);
    });
});

loginBtn.addEventListener("click", () => {
  let email = document.getElementById("email").value;
  let password = document.getElementById("password").value;
  firebase.auth().signInWithEmailAndPassword(email, password)
    .then((userCredential) => {
      alert("User logged in successfully!");
    })
    .catch((error) => {
      alert(error.message);
    });
});

logoutBtn.addEventListener("click", () => {
  firebase.auth().signOut().then(() => {
    alert("User logged out successfully!");
  }).catch((error) => {
    alert(error.message);
  });
});

searchBtn.addEventListener("click", () => {
      let countryName = countryInp.value;
      let finalURL = `https://restcountries.com/v3.1/name/${countryName}?fullText=true`;

      result.innerHTML = `<h3>Loading...</h3>`;

      fetch(finalURL)
        .then(response => response.json())
        .then(data => {
            const country = data[0];
            result.innerHTML = `
                <img src="${country.flags.svg}" class="flag-img">
                <h2>${country.name.common}</h2>
                <div class="data-wrapper">
                    <h4>Capital:</h4>
                    <span>${country.capital[0]}</span>
                </div>
                <div class="data-wrapper">
                    <h4>Continent:</h4>
                    <span>${country.continents[0]}</span>
                </div>
                <div class="data-wrapper">
                    <h4>Population:</h4>
                    <span>${country.population}</span>
                </div>
                <div class="data-wrapper">
                    <h4>Currency:</h4>
                    <span>${country.currencies[Object.keys(country.currencies)[0]].name} - ${Object.keys(country.currencies)[0]}</span>
                </div>
                <div class="data-wrapper">
                    <h4>Common Languages:</h4>
                    <span>${Object.values(country.languages).join(", ")}</span>
                </div>
                <div id="map"></div>
            `;

            // Initialize Mapbox
            mapboxgl.accessToken = 'YOUR_MAPBOX_ACCESS_TOKEN';
            var map = new mapboxgl.Map({
              container: 'map',
              style: 'mapbox://styles/mapbox/streets-v11',
              center: [country.latlng[1], country.latlng[0]],
              zoom: 5
            });

                        new mapboxgl.Marker()
              .setLngLat([country.latlng[1], country.latlng[0]])
              .addTo(map);
            })
            .catch(error => {
            result.innerHTML = `<h3>Error: ${error.message}</h3>`;
            });
            });

            compareBtn.addEventListener("click", () => {
              let countryName = countryCompareInp.value;
              let finalURL = `https://restcountries.com/v3.1/name/${countryName}?fullText=true`;

              compareResult.innerHTML = `<h3>Loading...</h3>`;

              fetch(finalURL)
                .then(response => response.json())
                .then(data => {
                  const country = data[0];
                  compareResult.innerHTML = `
                <div class="country">
                    <img src="${country.flags.svg}" class="flag-img">
                    <h2>${country.name.common}</h2>
                    <div class="data-wrapper">
                        <h4>Capital:</h4>
                        <span>${country.capital[0]}</span>
                    </div>
                    <div class="data-wrapper">
                        <h4>Continent:</h4>
                        <span>${country.continents[0]}</span>
                    </div>
                    <div class="data-wrapper">
                        <h4>Population:</h4>
                        <span>${country.population}</span>
                    </div>
                    <div class="data-wrapper">
                        <h4>Currency:</h4>
                        <span>${country.currencies[Object.keys(country.currencies)[0]].name} - ${Object.keys(country.currencies)[0]}</span>
                    </div>
                    <div class="data-wrapper">
                        <h4>Common Languages:</h4>
                        <span>${Object.values(country.languages).join(", ")}</span>
                    </div>
                    <div id="compare-map-${countryName}" class="compare-map"></div>
                </div>
            `;

                
                  var compareMap = new mapboxgl.Map({
                    container: `compare-map-${countryName}`,
                    style: 'mapbox://styles/mapbox/streets-v11',
                    center: [country.latlng[1], country.latlng[0]],
                    zoom: 5
                  });

                  new mapboxgl.Marker()
                    .setLngLat([country.latlng[1], country.latlng[0]])
                    .addTo(compareMap);
                })
                .catch(error => {
                  compareResult.innerHTML = `<h3>Error: ${error.message}</h3>`;
                });
            });


            signupBtn.addEventListener("click", () => {
              let email = document.getElementById("email").value;
              let password = document.getElementById("password").value;
              firebase.auth().createUserWithEmailAndPassword(email, password)
                .then((userCredential) => {
                  alert("User signed up successfully!");
                })
                .catch((error) => {
                  alert(error.message);
                });
            });

            loginBtn.addEventListener("click", () => {
              let email = document.getElementById("email").value;
              let password = document.getElementById("password").value;
              firebase.auth().signInWithEmailAndPassword(email, password)
                .then((userCredential) => {
                  alert("User logged in successfully!");
                })
                .catch((error) => {
                  alert(error.message);
                });
            });

            logoutBtn.addEventListener("click", () => {
              firebase.auth().signOut().then(() => {
                alert("User logged out successfully!");
              }).catch((error) => {
                alert(error.message);
              });
            });